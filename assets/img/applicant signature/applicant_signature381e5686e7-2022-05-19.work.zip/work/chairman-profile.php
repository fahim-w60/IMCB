<?php include('includes/header.php')?>

<!--Page header & Title-->
<section id="page_header">
<div class="page_title">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
         <h2 class="title">Mr. Raj Kamal</h2>
         <p>Founder Chairman of Raj-Kamal Everbest Corporation Ltd.</p>
      </div>
    </div>
  </div>
</div>  
</section>

<!--Welcome-->
<section id="welcome" class="padding profile">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
         <h2 class="heading">About Founder Chairman</h2>
         <hr class="heading_space">
      </div>
      <div class="col-md-7 col-sm-6">
        <ul class="welcome_list">
          <li>Name: Mr. Raj Kamal</li>
          <li>Position: Founder Chairman</li>
          <li>Office: Purana Paltan, Dhaka-1000</li>
          <li>Phone: +880-1911-222333</li>
          <li>Email: founder@mail.com</li>
          <li>Detail About Him: <p>Raj-Kamal was born on 13th March, 1950. After completing education, he settled at Ataikula village in Pabna district where his father was working as a Medical Officer in an outdoor dispensary. In 1972, he started a small pharmacy in Ataikula village which is about 160 km off capital Dhaka in the north-west part of Bangladesh. Now that small company of 1978 is a publicly listed diversified group of companies employing more than 28,000 people. </p></li>
          <li>Speech: <blockquote class="bg_grey half-space">Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel 
          illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue 
          duis dolore te feugait nulla facilisi.
        </blockquote></li>
        </ul> 
      </div>
      <div class="col-md-5 col-sm-6">
       <img class="img-responsive" src="images/welcome.jpg" alt="welcome bistro">

       <div class="signature align-items-center"> 
          <div class="col-md-6"> 
            <div class="signature-img"> 
              <img src="images/sign.png" alt="" class="img-fluid">
            </div>
          </div>
          <div class="col-md-6">
            <div class="sign-author"> 
              <h3>Mr. Raj Kamal</h3>
              <p>Founder Chairman</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section> 



<?php include('includes/footer.php')?>