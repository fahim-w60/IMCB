<?php include('includes/header.php')?>

<!--Page header & Title-->
<section id="page_header">
<div class="page_title">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
         <h2 class="title">Company Profile</h2>
         <p>Raj-Kamal Everbest Corporation Ltd.</p>
      </div>
    </div>
  </div>
</div>  
</section>

<!--Welcome-->
<section id="welcome" class="padding profile chairman-message">
  <div class="container">
    <div class="row">
      
      <div class="col-md-12 col-sm-12">
        <img class="img-responsive" src="images/company.png" alt="Company">
      </div>

      <div class="col-md-12">
        <div class="company-profile"> 
          <div class="overview">
            <h2 class="heading">Background of the Organization</h2>
            <hr class="space25"> 
            <p>Raj-kamal Food Products Limited is a Foods stuff based company. "RAJ-KAMAL" is currently one of the most well known brand among the millions of people in Bangladesh and abroad. Since its origin in 1995, RAJ-KAMAL Foods has grown up in stature and became one of the largest Indian spices and dry food exporter in Bangladesh. RAJ-KAMAL is the pioneer in Bangladesh to be involved procures raw material directly from the farmers and processes through state of the machinery at our factory into hygienically packed food and drinks products. The brand "RAJ-KAMAL" has established itself in every category of food and can boost a product range from Drinks, Confectionery, Snacks, and Spices and Bakery products.
            The company gained acceptance from the consumers through its superior quality, the company had grown tremendously with being a pioneer. The company Introduced ethnic dry food in Middle East market especially in Saudi Arabia. We are exporting our products in foreign market. Sell abroad Countries are KSA, Dubai (UAE), Jordan, Malaysia. We have a very good distribution network in all over the KSA.
            We have the capability to provide a good number of products to support our clients. We are confident that we can ensure the highest quality of products and competitive prices. More specifically, we are involved with both manufacturing and exporting of dry foodstuffs in different countries across the world.</p>
         </div>

         <div class="overview">
            <h2 class="heading">Basic Informantion</h2>
            <hr class="space25"> 
            <ul class="welcome_list">
              <li>Full Name: Raj-Kamal Everbest Corporation Ltd.</li>
              <li>Year of Establishment: 1996</li>
              <li>Founder Name: Mr. Raj Kamal</li>
              <li>Registration No: C-3885</li>
              <li>Company Type: Manufacturer, Trading Company, Distributor/Wholesale</li>
              <li>Number of employees: 9,147</li>
              <li>Factory Size: 5,000-10,000 square meters</li>
            </ul> 
         </div>

         <div class="overview">
            <h2 class="heading">Board of Directors</h2>
            <hr class="space25"> 
            <ul class="welcome_list">
              <li>
                Mr. Raj Kamal
                <span class="designation">Founder Chairman</span>
              </li>
              <li>
                Mr. Person One
                <span class="designation">Chairman</span>
              </li>
               <li>
                Mr. Person Two
                <span class="designation">Managing Director</span>
              </li>
              <li>
                Mr. Person Three
                <span class="designation">Director</span>
              </li>
            </ul> 
         </div>

         <div class="overview">
            <h2 class="heading">Advising Bank</h2>
            <hr class="space25"> 
            <ul class="welcome_list">
              <li>
                Sonali Bank Ltd.
                <span class="designation">Foreign Exchange Corporate Branch, Motijheel</span>
              </li>
              <li>
                National Bank Ltd.
                <span class="designation">Malibagh Branch</span>
              </li>
              <li>
                Pubali Bank Ltd.
                <span class="designation">Mouchak Branch</span>
              </li>
              <li>
                Exim Bank Ltd.
                <span class="designation">Malibagh Branch</span>
              </li>
              <li>
                Standard Chartered Bank
                <span class="designation">Dhaka</span>
              </li>
            </ul> 
         </div>

        </div>
      </div>
    </div>
  </div>
</section> 



<?php include('includes/footer.php')?>