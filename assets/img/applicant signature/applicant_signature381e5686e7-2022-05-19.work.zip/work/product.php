<?php include('includes/header.php')?>


<!--Page header & Title-->
<section id="page_header">
<div class="page_title">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
         <h2 class="title">Our Products</h2>
         <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit</p>
      </div>
    </div>
  </div>
</div>  
</section>


<!-- Food Gallery -->
<section id="gallery" class="padding product-page">
  <div class="container">
      <div class="row">
         <div class="col-md-12 text-center">
            <h2 class="heading ">Our &nbsp; Products</h2>
            <hr class="heading_space">
          </div>
        </div>

        <div class="row">
         <div class="col-md-3">
            <div class="sidenav work-filter">
              <a href="javascript:;" data-filter="all" class="filter"><h2 class="heading">Categories</h2></a>
              <hr>
              <div class="single-category"> 
                <button class="dropdown-btn filter" href="javascript:;" data-filter=".kewdala">Biscuits 
                  <i class="fa fa-caret-down"></i>
                </button>
                <div class="dropdown-container">
                  <ul>
                    <li><a href="javascript:;" data-filter=".chili" class="filter">Biscuit</a></li>
                    <li><a href="javascript:;" data-filter=".turmeric" class="filter">Cake</a></li>
                  </ul>
                </div>
              </div>

              <div class="single-category"> 
                <button class="dropdown-btn filter" href="javascript:;" data-filter=".dogaire">Culinary 
                  <i class="fa fa-caret-down"></i>
                </button>
                <div class="dropdown-container">
                  <button class="dropdown-btn">Spice
                    <i class="fa fa-caret-down"></i>
                  </button>
                  <div class="dropdown-container">
                    <ul>
                      <li><a href="javascript:;" data-filter=".bela" class="filter">Basic Spice</a></li>
                      <li><a href="javascript:;" data-filter=".sweet_toast" class="filter">Mixed Spice</a></li>
                      <li><a href="javascript:;" data-filter=".drycake" class="filter">Whole Spice</a></li>
                    </ul>
                  </div>
                  <button class="dropdown-btn">Paste
                    <i class="fa fa-caret-down"></i>
                  </button>
                  <div class="dropdown-container">
                    <ul>
                      <li><a href="javascript:;" data-filter=".aromatic" class="filter">Spice Paste</a></li>
                    </ul>
                  </div>
                  <button class="dropdown-btn">Oil
                  </button>
                  <button class="dropdown-btn">Rice & Pulse
                  </button>
                  <button class="dropdown-btn">Flour
                  </button>
                  <button class="dropdown-btn">Vermichili
                  </button>
                </div>
              </div>

              <div class="single-category"> 
                <button class="dropdown-btn filter" href="javascript:;" data-filter=".kewdala">Beverage </button>
              </div>
              <div class="single-category"> 
                <button class="dropdown-btn filter" href="javascript:;" data-filter=".kewdala">Snacks</button>
              </div>
              <div class="single-category"> 
                <button class="dropdown-btn filter" href="javascript:;" data-filter=".kewdala">Other Items</button>
              </div>
            </div>
      </div>

    <div class="col-md-9">
      <div class="row product-page-item">
      <div class="zerogrid">
        <div class="wrap-container">
          <div class="wrap-content clearfix home-gallery">
            <div class="col-1-3 mix work-item chili kewdala">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/product1.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/product1.jpg" data-fancybox-group="gallery" title="Chilli Powder"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                   <div class="product-detail"> 
                      <a href="single-product.php"><h5>Chili Bottle 250 GM</h5></a>
                      <!-- <h6>৳40</h6> -->
                    </div>
                </div>
              </div>
            </div>
            <div class="col-1-3 mix work-item coriander kewdala">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/product2.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/product2.jpg" data-fancybox-group="gallery" title="Coriander Powder"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                   <div class="product-detail"> 
                      <a href="single-product.php"><h5>Coriander Bottle 250 GM</h5></a>
                      <!-- <h6>৳40</h6> -->
                    </div>
                </div>
              </div>
            </div>
            <div class="col-1-3 mix work-item turmeric kewdala">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/product3.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/product3.jpg" data-fancybox-group="gallery" title="Turmeric Powder"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                   <div class="product-detail"> 
                      <a href="single-product.php"><h5>Turmeric Bottle 250 GM</h5></a>
                      <!-- <h6>৳40</h6> -->
                    </div>
                </div>
              </div>
            </div>
            <div class="col-1-3 mix work-item bbq kewdala">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/product4.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/product4.jpg" data-fancybox-group="gallery" title="BBQ Chanachur"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                   <div class="product-detail"> 
                      <a href="single-product.php"><h5>BBQ Chanachur 250 GM</h5></a>
                      <!-- <h6>৳40</h6> -->
                    </div>
                </div>
              </div>
            </div>  
            <div class="col-1-3 mix work-item jhalmuri kewdala">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/product5.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/product5.jpg" data-fancybox-group="gallery" title="Jhal Muri"><i class=" icon-eye6"></i></a>
                    </div> 
                  </div>
                   <div class="product-detail"> 
                      <a href="single-product.php"><h5>Jhal Muri</h5></a>
                      <!-- <h6>৳40</h6> -->
                    </div>
                </div>
              </div>
            </div>
            <div class="col-1-3 mix work-item laccha kewdala">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/product6.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/product6.jpg" data-fancybox-group="gallery" title="Laccha Shemai"><i class=" icon-eye6"></i></a>
                    </div>
                  </div> 
                   <div class="product-detail"> 
                      <a href="single-product.php"><h5>Laccha Shemai</h5></a>
                      <!-- <h6>৳40</h6> -->
                    </div>
                </div>
              </div>
            </div>
            <div class="col-1-3 mix work-item mustard_oil kewdala">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/product7.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/product7.jpg" data-fancybox-group="gallery" title="Mustard Oil"><i class=" icon-eye6"></i></a>
                    </div>
                  </div> 
                   <div class="product-detail"> 
                      <a href="single-product.php"><h5>Mustard Oil 500 ML</h5></a>
                      <!-- <h6>৳40</h6> -->
                    </div>
                </div>
              </div>
            </div>
            <div class="col-1-3 mix work-item kalijira kewdala">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/product8.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/product8.jpg" data-fancybox-group="gallery" title="Shefa Kalijira Oil"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                   <div class="product-detail"> 
                      <a href="single-product.php"><h5>Shefa Kalijira Oil</h5></a>
                      <!-- <h6>৳40</h6> -->
                    </div>
                </div>
              </div>
            </div>
            <div class="col-1-3 mix work-item isabgul kewdala">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/product9.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/product9.jpg" data-fancybox-group="gallery" title="Husk Isabgul"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                   <div class="product-detail"> 
                      <a href="single-product.php"><h5>Husk Isabgul</h5></a>
                      <!-- <h6>৳40</h6> -->
                    </div>
                </div>
              </div>
            </div>
            <div class="col-1-3 mix work-item bela dogaire">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/product10.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/product10.jpg" data-fancybox-group="gallery" title="Bela Biscuit"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                   <div class="product-detail"> 
                      <a href="single-product.php"><h5>Bela Biscuit</h5></a>
                      <!-- <h6>৳40</h6> -->
                    </div>
                </div>
              </div>
            </div>
            <div class="col-1-3 mix work-item sweet_toast dogaire">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/product11.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/product11.jpg" data-fancybox-group="gallery" title="Sweet Toast"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                   <div class="product-detail"> 
                      <a href="single-product.php"><h5>Sweet Toast</h5></a>
                      <!-- <h6>৳40</h6> -->
                    </div>
                </div>
              </div>
            </div>  
            <div class="col-1-3 mix work-item drycake dogaire">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/product12.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/product12.jpg" data-fancybox-group="gallery" title="Dry Cake"><i class=" icon-eye6"></i></a>
                    </div> 
                  </div>
                   <div class="product-detail"> 
                      <a href="single-product.php"><h5>Dry Cake</h5></a>
                      <!-- <h6>৳40</h6> -->
                    </div>
                </div>
              </div>
            </div>
            <div class="col-1-3 mix work-item aromatic dogaire">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/product13.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/product13.jpg" data-fancybox-group="gallery" title="Aromatic Chinigura Rice"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                   <div class="product-detail"> 
                      <a href="single-product.php"><h5>Aromatic Chinigura Rice</h5></a>
                      <!-- <h6>৳40</h6> -->
                    </div> 
                </div>
              </div>
            </div>
            <div class="col-1-3 mix work-item rice dogaire">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/product14.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/product14.jpg" data-fancybox-group="gallery" title="Flattened Rice"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                   <div class="product-detail"> 
                      <a href="single-product.php"><h5>Flattened Rice</h5></a>
                      <!-- <h6>৳40</h6> -->
                    </div> 
                </div>
              </div>
            </div>
            <div class="col-1-3 mix work-item atta dogaire">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/product15.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/product15.jpg" data-fancybox-group="gallery" title="Chakki Fresh Atta"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                   <div class="product-detail"> 
                      <a href="single-product.php"><h5>Chakki Fresh Atta</h5></a>
                      <!-- <h6>৳40</h6> -->
                    </div>
                </div>
              </div>
            </div>
          </div>
        </div>
       </div>
      </div>
    </div>
  </div>
</section>


<?php include('includes/footer.php')?>