<?php include('includes/header.php')?>

<!--Page header & Title-->
<section id="page_header">
<div class="page_title">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
         <h2 class="title">Message From DMD</h2>
         <p>Raj-Kamal Everbest Corporation Ltd.</p>
      </div>
    </div>
  </div>
</div>  
</section>

<!--Welcome-->
<section id="welcome" class="padding profile chairman-message">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
         <h2 class="heading">Message From Our DMD</h2>
         <hr class="heading_space">
      </div>
      <div class="col-md-12 col-sm-12">
       <img class="img-responsive" src="images/dmd.jpg" alt="Chairman">

       <div class="message"> 
        <h2>Hasan Imam (Shajib)</h2>
        <h5>DMD</h5>
        <p><blockquote class="bg_grey half-space"><b>Assalamu Alaikum,</b> <br>In 1997, 22 years ago, we collected from our shareowners Tk. 53 Crores through a Rights Issue. At that time we had a Turnover of Tk. 80 Crores, Net Asset Employed was Tk. 35 Crores and the total number of employees was 869. 
        “ Over these years we have grown Raj-Kamal as the largest Production chain in the country serving several million customers a year and earning “Superbrand” recognition. ”
        Since then, we have expanded our businesses through bank borrowing. We have now grown to a turnover of Tk. 6314 Crores, Net Asset Employed to Tk. 951 Crore and the number of employees are 9147. The growth has been remarkable. At the same time profits generated could not only finance handsome dividend year after year over the last two decades but also could set aside funds to increase shareholders equity and when need be use the fund to support consistent dividend Payout Policy.</blockquote></p>
       </div>

       <div class="col-md-offset-6 col-md-6"> 
        <div class="signature align-items-center"> 
          <div class="col-md-6"> 
            <div class="signature-img"> 
              <img src="images/sign.png" alt="Signature" class="img-fluid">
            </div>
          </div>
          <div class="col-md-6">
            <div class="sign-author"> 
              <h3>Hasan Imam (Shajib)</h3>
              <p>DMD</p>
            </div>
          </div>
        </div>
       </div>
      </div>
    </div>
  </div>
</section> 



<?php include('includes/footer.php')?>