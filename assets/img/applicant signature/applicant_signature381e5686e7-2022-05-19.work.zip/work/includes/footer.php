<!--Footer-->
<footer class="padding-top footer">
  <div class="container">
    <div class="row">
      <div class="col-md-3 col-sm-6 footer_column">
        <h4 class="heading">Why Raj-Kamal Everbest?</h4>
        <hr class="half_space">
        <p class="half_space">"RAJ-KAMAL" is currently one of the most well known brand among the millions of people in Bangladesh and abroad. <br> Since its origin in 1995, RAJ-KAMAL Foods has grown up in stature and became one of the largest Indian spices and dry food exporter in Bangladesh.</p>
      </div>
      <div class="col-md-3 col-sm-6 footer_column">
        <h4 class="heading">Quick Links</h4>
        <hr class="half_space">
        <ul class="widget_links">
          <li><a href="index.php">Home</a></li>
          <li><a href="media.php">Gallery</a></li>
          <li><a href="about.php">About Us</a></li>
          <li><a href="chairman-profile.php">Chairman Profile</a></li>
          <li><a href="product.php">Products</a></li>
          <li><a href="company-profile.php">Company Profile</a></li>
          <li><a href="export.php">Export</a></li>
          <li><a href="factory-contact.php">Factory</a></li>
        </ul>
      </div>
      <div class="col-md-3 col-sm-6 footer_column">
        <h4 class="heading">Newsletter</h4>
        <hr class="half_space">
        <p class="icon"><i class="icon-dollar"></i>Sign up with your name and email to get updates fresh updates.</p>
        <div id="result1" class="text-center"></div>        
        
       <form action="" method="" onSubmit="return false" class="newsletter">
          <div class="form-group">
            <input type="email" placeholder="E-mail Address" required name="EMAIL" id="EMAIL" class="form-control" />
          </div>
          <div class="form-group">
            <input type="submit" class="btn-submit button3" value="Subscribe" />
          </div>
        </form>
      </div>
      <div class="col-md-3 col-sm-6 footer_column">
        <h4 class="heading">Get in Touch</h4>
        <hr class="half_space">
        <p>Restaurant, to consequat ipsum nec sagittis sem.</p>
        <p class="address"><i class="icon-location"></i>Corporate Office: Paramount Heights (3rd Floor), Suite#3/A, 65/2/1, Box Culvert Road, Purana Paltan, Dhaka-1000, Bangladesh.</p>
        <p class="address"><i class="icon-location"></i>Factory: Rayerbagh, Chittagong Road, Dhaka, Bangladesh</p>
        <p class="address"><i class="fa fa-phone"></i>88-02-7125613</p>
        <p class="address"><i class="icon-dollar"></i><a href="mailto:rajkamal_bd@hotmail.com">rajkamal_bd@hotmail.com</a></p>
      </div> 
    </div>
    <div class="row">
     <div class="col-md-12">
        <div class="copyright clearfix">
          <p>Copyright &copy; 2021 Raj-Kamal Everbest Corporation Ltd. All Rights Reserved</p>
          <ul class="social_icon">
            <li><a href="https://www.facebook.com/rajkamal.corporation/" class="facebook"><i class="icon-facebook5"></i></a></li>
            <li><a href="https://www.youtube.com/user/rajkamal1077" class="google"><i class="icon-youtube"></i></a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</footer>

  <a href="#" id="back-top"><i class="fa fa-angle-up fa-2x"></i></a>


  	<!-- Search Modal -->
    <div class="modal fade" id="searchModal" tabindex="-1" role="dialog" aria-labelledby="searchModalLabel">
      	<div class="container">
      		<div class="row">
      			<div class="col-md-12"> 
      				<div class="modal-dialog" role="document">
				        <div class="modal-content">
				          <!-- <div class="modal-header">
				            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>

				          </div> -->
				          <div class="modal-body">

				            <form class="navbar-form " role="search">
				              <div class="form-group">

				                <input type="text" class="form-control" placeholder="Search Entire Website">
				              </div>
				              <button type="submit" class="btn btn-default">Search</button>
				              
				              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				            </form>


				          </div>


				        </div>
				    </div>
      			</div>
      		</div>
      	</div>
    </div>

  <script src="js/jquery-2.2.3.js" type="text/javascript"></script>
  <script src="js/bootstrap.min.js" type="text/javascript"></script>
  <script src="js/jquery.themepunch.tools.min.js"></script>
  <script src="js/jquery.themepunch.revolution.min.js"></script>
  <script src="js/revolution.extension.layeranimation.min.js"></script>
  <script src="js/revolution.extension.navigation.min.js"></script>
  <script src="js/revolution.extension.parallax.min.js"></script>
  <script src="js/revolution.extension.slideanims.min.js"></script>
  <script src="js/revolution.extension.video.min.js"></script>
  <script src="js/slider.js" type="text/javascript"></script>
  <script src="js/owl.carousel.min.js" type="text/javascript"></script>
  <script src="js/jquery.parallax-1.1.3.js"></script>
  <script src="js/jquery.mixitup.min.js"></script>
  <script src="js/jquery-countTo.js"></script>
  <script src="js/jquery.appear.js"></script>  
  <script src="js/jquery.fancybox.js"></script>
  <script src="js/functions.js" type="text/javascript"></script>

  <script>
    /* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
    var dropdown = document.getElementsByClassName("dropdown-btn");
    var i;

    for (i = 0; i < dropdown.length; i++) {
      dropdown[i].addEventListener("click", function() {
      this.classList.toggle("active");
      var dropdownContent = this.nextElementSibling;
      if (dropdownContent.style.display === "block") {
      dropdownContent.style.display = "none";
      } else {
      dropdownContent.style.display = "block";
      }
      });
    }
  </script>
   
  </body>
</html>
