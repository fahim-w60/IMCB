<?php include('includes/header.php')?>

<!--Page header & Title-->
<section id="page_header">
<div class="page_title">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
         <h2 class="title">Contact Us</h2>
         <p>Raj-Kamal Everbest Corporation Ltd.</p>
      </div>
    </div>
  </div>
</div>  
</section>


<!--Contact Form & Address-->
<section class="padding contact-page">
  <div class="container order-page">
    <div class="row">
      <div class="col-md-4 col-sm-4 bistro">
        <h2 class="heading">Address Info</h2>
        <hr class="heading_space"> 

        <ul class="welcome_list">
            <li><strong>Phone:</strong> 88-02-7125613</li>
            <li><strong>Email:</strong> <a href="mailto:rajkamal_bd@hotmail.com">rajkamal_bd@hotmail.com</a></li>
            <li><strong>Website:</strong> <a href="http://rajkamal.com.bd/">rajkamal.com.bd</a></li>
            <li><strong>Corporate Office Address:</strong> Paramount Heights (3rd Floor), Suite#3/A, 65/2/1, Box Culvert Road, Purana Paltan, Dhaka-1000, Bangladesh.</li>
            <li><strong>Factory Address:</strong> Rayerbagh, Chittagong Road, Dhaka, Bangladesh</li>
        </ul>
         <ul class="social_icon">
            <li class="black"><a href="https://www.facebook.com/rajkamal.corporation/" class="facebook"><i class="icon-facebook5"></i></a></li>
            <li class="black"><a href="https://www.youtube.com/user/rajkamal1077" class="google"><i class="icon-youtube"></i></a></li>
          </ul>
      </div>

      <div class="col-md-8 col-sm-8">
        <h2 class="heading">Get in Touch</h2>
        <hr class="heading_space">
        <form class="callus" onSubmit="return false"  id="contact_form">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label for="name">Your Name <span class="text-danger">*</span></label>
                <input class="form-control" type="text" name="name" id="name"  placeholder="Please Enter Your Name" required />
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label for="email">Your Email Address <span class="text-danger">*</span></label>
                <input class="form-control" type="email" name="email" id="email"  placeholder="Please Enter Your Email Address" required />
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label for="phone">Phone / Mobile <span class="text-danger">*</span></label>
                <input class="form-control" type="tel" name="phone" id="phone"  placeholder="Please Enter Phone Number" required />
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label for="query">Your Query is for <span class="text-danger">*</span></label>
                <select name="query" id="query" class="form-control"> 
                  <option value="">--Select--</option>
                  <option value="">Select One</option>
                  <option value="">Select Two</option>
                  <option value="">Others</option>
                </select>
              </div>
            </div>
             <div class="col-md-12">
              <div class="form-group">
                <label for="subject">Subject <span class="text-danger">*</span></label>
                <input class="form-control" type="text" name="subject" id="subject"  placeholder="Subject Required" required />
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <label for="message">Query <span class="text-danger">*</span></label>
                <textarea placeholder="Please Enter Your Message" name="message" id="message"></textarea>
              </div>
              <div class="form-group">
                 <div class="btn-submit button3">
                    <input type="submit" value="Send Message" id="btn_contact_submit">
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>

<?php include('includes/footer.php')?>