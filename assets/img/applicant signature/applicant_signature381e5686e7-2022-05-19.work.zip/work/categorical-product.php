<?php include('includes/header.php')?>


<!--Page header & Title-->
<section id="page_header">
	<div class="page_title">
	  <div class="container">
	    <div class="row">
	      <div class="col-md-12">
	         <h2 class="title">Spicy Products</h2>
	         <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit</p>
	      </div>
	    </div>
	  </div>
	</div>  
</section>


<!-- Food Gallery -->
<section id="gallery" class="padding product-page">
  <div class="container">
      <div class="row">
         <div class="col-md-12 text-center">
            <h2 class="heading ">Spicy &nbsp; Products</h2>
            <hr class="heading_space">
          </div>
        </div>

	    <div class="row product-page-item">
	      <div class="zerogrid">
	        <div class="wrap-container">
	          <div class="wrap-content clearfix home-gallery">
	            <div class="col-1-4 work-item chili">
	              <div class="wrap-col">
	                <div class="item-container">
	                  <div class="image">
	                    <img src="images/product1.jpg" alt="cook"/>
	                    <div class="overlay">
	                        <a class="fancybox overlay-inner" href="images/product1.jpg" data-fancybox-group="gallery" title="Spice Product"><i class=" icon-eye6"></i></a>
	                    </div>
	                  </div>
	                  <div class="product-detail"> 
                    	<a href="single-product.php"><h5>Chili Bottle 250 GM</h5></a>
                    	<!-- <h6>৳40</h6> -->
                    </div>
	                </div>
	              </div>
	            </div>
	            <div class="col-1-4 work-item coriander">
	              <div class="wrap-col">
	                <div class="item-container">
	                  <div class="image">
	                    <img src="images/product2.jpg" alt="cook"/>
	                    <div class="overlay">
	                        <a class="fancybox overlay-inner" href="images/product2.jpg" data-fancybox-group="gallery" title="Spice Product"><i class=" icon-eye6"></i></a>
	                    </div>
	                  </div>
	                  <div class="product-detail"> 
                    	<a href="single-product.php"><h5>Coriander Bottle 250 GM</h5></a>
                    	<!-- <h6>৳40</h6> -->
                      </div>
	                </div>
	              </div>
	            </div>
	            <div class="col-1-4 work-item turmeric">
	              <div class="wrap-col">
	                <div class="item-container">
	                  <div class="image">
	                    <img src="images/product3.jpg" alt="cook"/>
	                    <div class="overlay">
	                        <a class="fancybox overlay-inner" href="images/product3.jpg" data-fancybox-group="gallery" title="Spice Product"><i class=" icon-eye6"></i></a>
	                    </div>
	                  </div>
	                  <div class="product-detail"> 
                    	<a href="single-product.php"><h5>Turmeric Bottle 250 GM</h5></a>
                    	<!-- <h6>৳40</h6> -->
                      </div>
	                </div>
	              </div>
	            </div>
	            <div class="col-1-4 work-item spice">
	              <div class="wrap-col">
	                <div class="item-container">
	                  <div class="image">
	                    <img src="images/gallery11.jpg" alt="cook"/>
	                    <div class="overlay">
	                        <a class="fancybox overlay-inner" href="images/gallery11.jpg" data-fancybox-group="gallery" title="Spice Product"><i class=" icon-eye6"></i></a>
	                    </div>
	                  </div>
	                  <div class="product-detail"> 
                    	<a href="single-product.php"><h5>Chicken Masala 250 GM</h5></a>
                    	<!-- <h6>৳65</h6> -->
                      </div>
	                </div>
	              </div>
	            </div>  
	        </div> 

	        <div class="row product-page-item"> 
	            <div class="col-1-4 work-item spice">
	              <div class="wrap-col">
	                <div class="item-container">
	                  <div class="image">
	                    <img src="images/gallery13.jpg" alt="cook"/>
	                    <div class="overlay">
	                        <a class="fancybox overlay-inner" href="images/gallery13.jpg" data-fancybox-group="gallery" title="Spice Product"><i class=" icon-eye6"></i></a>
	                    </div>
	                  </div> 
	                  <div class="product-detail"> 
                    	<a href="single-product.php"><h5>Chili Bottle 500 GM</h5></a>
                    	<!-- <h6>৳80</h6> -->
                      </div>
	                </div>
	              </div>
	            </div>
	            <div class="col-1-4 work-item spice">
	              <div class="wrap-col">
	                <div class="item-container">
	                  <div class="image">
	                    <img src="images/gallery15.jpg" alt="cook"/>
	                    <div class="overlay">
	                        <a class="fancybox overlay-inner" href="images/gallery15.jpg" data-fancybox-group="gallery" title="Spice Product"><i class=" icon-eye6"></i></a>
	                    </div>
	                  </div>
	                  <div class="product-detail"> 
                    	<a href="single-product.php"><h5>Turmeric Bottle 500 GM</h5></a>
                    	<!-- <h6>৳80</h6> -->
                      </div>
	                </div>
	              </div>
	            </div>
	          </div>
	        </div>
	       </div>
	      </div>
		</section>


<?php include('includes/footer.php')?>