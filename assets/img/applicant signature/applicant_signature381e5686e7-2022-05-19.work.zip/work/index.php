<?php include('includes/header.php')?>



  <!-- REVOLUTION SLIDER -->			

	<div id="rev_slider_34_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container header-slider" data-alias="news-gallery34" style="margin:0px auto;background-color:#ffffff;padding:0px;margin-top:0px;margin-bottom:0px;">
	<!-- START REVOLUTION SLIDER 5.0.7 fullwidth mode -->
		<div id="rev_slider_34_1" class="rev_slider fullwidthabanner" style="display:none;" data-version="5.0.7">
			<ul>	<!-- SLIDE  -->
				<li data-index="rs-129" data-transition="fade" data-slotamount="default" data-rotate="0"  data-fstransition="fade" data-fsmasterspeed="1500" data-fsslotamount="7"  data-title="Biscuit &nbsp; Cake" data-description="Various Biscuit & Cake">
					<!-- MAIN IMAGE -->
					<img src="images/rajkamal.jpg" alt="Banner" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
					<!-- LAYER NR. 2 -->
					<h1 class="tp-caption tp-resizeme" 
                    data-x="left" data-hoffset="15"
                    data-y="70" 
                    data-transform_idle="o:1;"
                    data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" 
                    data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" 
                    data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
                    data-mask_out="x:0;y:0;s:inherit;e:inherit;" 
                    data-start="500" 
                    data-splitin="none" 
                    data-splitout="none" 
                    style="z-index: 6;">
                    <span class="small_title">Raj-Kamal Everbest Corporation Ltd.</span> <br> We mean &nbsp;<span class="color"> Quality</span>
                 </h1>
					<!-- LAYER NR. 2 -->
                  <p class="tp-caption tp-resizeme"
                    data-x="left" data-hoffset="15"
                    data-y="210" 
                    data-transform_idle="o:1;"
                    data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" 
                    data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" 
                    data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
                    data-mask_out="x:0;y:0;s:inherit;e:inherit;" 
                    data-start="800"
                    style="z-index: 9;">An 100% Export Oriented Company.
                    
                  </p>
                  <div class="tp-caption fade tp-resizeme"
                     data-x="left" data-hoffset="15"
                     data-y="280"
                     data-width = "full"  
                     data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;"
                     data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;"  
                     data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
                     data-mask_out="x:0;y:0;s:inherit;e:inherit;" 
                    data-start="1200"
                     style="z-index: 12;">
                 <a href="#order-form" class="btn-common btn-white page-scroll slider-btn">Order Now</a>
              </div>
				</li>
				
				<li class="text-center" data-index="rs-130" data-transition="slideleft" data-slotamount="default" data-rotate="0"  data-title="Curry Masalas" data-description="Get Variety of Masalas">
					<img src="images/rajkamal3.jpg"  alt="Banner" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
            <h1 class="tp-caption tp-resizeme" 
              data-x="center" data-hoffset="15"
              data-y="70" 
              data-transform_idle="o:1;"
              data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" 
              data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" 
              data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
              data-mask_out="x:0;y:0;s:inherit;e:inherit;" 
              data-start="500" 
              data-splitin="none" 
              data-splitout="none" 
              style="z-index: 6;">
              <span class="small_title">  Make Your Food More Delicious</span> <br> Using Variety of <span class="color">Masalas</span>
            </h1>
            <p class="tp-caption tp-resizeme"
              data-x="center" data-hoffset="15"
              data-y="210" 
              data-transform_idle="o:1;"
              data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" 
              data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" 
              data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
              data-mask_out="x:0;y:0;s:inherit;e:inherit;" 
              data-start="800"
              style="z-index: 9;">Variety of Masalas
            </p>
	
                
              <div class="tp-caption fade tp-resizeme"
               data-x="center" data-hoffset="15"
               data-y="280"
               data-width = "full"  
               data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;"
               data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;"  
               data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
               data-mask_out="x:0;y:0;s:inherit;e:inherit;" 
              data-start="1200"
               style="z-index: 12;">
              <a href="#specialities" class="btn-common btn-white page-scroll slider-btn">Learn &nbsp; More</a> &nbsp; <a href="#order-form" class="btn-common btn-orange page-scroll slider-btn">Order &nbsp; Now</a>
           </div>     
        </li>
			
		<li class="text-right" data-index="rs-131" data-transition="slideleft"   data-rotate="0" data-title="Bottle Spice" data-description="We Provide All Kinds Desi Spices">
			<img src="images/rajkamal.jpg" alt="Banner" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
            <h1 class="tp-caption tp-resizeme" 
              data-x="right" data-hoffset="" 
              data-y="70" 
              data-transform_idle="o:1;"
              data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" 
              data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" 
              data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
              data-mask_out="x:0;y:0;s:inherit;e:inherit;" 
              data-start="500" 
              data-splitin="none" 
              data-splitout="none" 
              style="z-index: 6;">
              <span class="small_title">All Kinds of</span> <br> &nbsp; Bottle &nbsp; <span class="color">Spices</span>
            </h1>
            <p class="tp-caption tp-resizeme"
              data-x="right" data-hoffset="" 
              data-y="210" 
              data-transform_idle="o:1;"
              data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" 
              data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" 
              data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
              data-mask_out="x:0;y:0;s:inherit;e:inherit;" 
              data-start="800"
              style="z-index: 9;">We Provide All Kinds Desi Spices in Bottle Size
            </p>
	
               <div class="tp-caption fade tp-resizeme"
                 data-x="right" data-hoffset=""
                 data-y="280"
                 data-width = "full" 
                 data-transform_idle="o:1;"
                 data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;"
                 data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;"  
                 data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
                 data-mask_out="x:0;y:0;s:inherit;e:inherit;" 
                data-start="1200"
                 style="z-index: 12;">
             <a href="#order-form" class="btn-common btn-white page-scroll slider-btn">Order Now</a>
           </div>  
          </li>


          <li class="text-right" data-index="rs-132" data-transition="slideleft" data-rotate="0" data-title="Rice" data-description="Perfume Chinigura Rice">
          <img src="images/rajkamal3.jpg" alt="Banner" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
            <h1 class="tp-caption tp-resizeme" 
              data-x="right" data-hoffset="" 
              data-y="70" 
              data-transform_idle="o:1;"
              data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" 
              data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" 
              data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
              data-mask_out="x:0;y:0;s:inherit;e:inherit;" 
              data-start="500" 
              data-splitin="none" 
              data-splitout="none" 
              style="z-index: 6;">
              <span class="small_title">We Have</span> <br> Various &nbsp; Kinds of &nbsp; <span class="color">Rice</span>
            </h1>
            <p class="tp-caption tp-resizeme"
              data-x="right" data-hoffset="" 
              data-y="210" 
              data-transform_idle="o:1;"
              data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" 
              data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" 
              data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
              data-mask_out="x:0;y:0;s:inherit;e:inherit;" 
              data-start="800"
              style="z-index: 9;">Get Perfume Chinigura Rice & Many More Variety of Rice
            </p>
  
               <div class="tp-caption fade tp-resizeme"
                 data-x="right" data-hoffset=""
                 data-y="280"
                 data-width = "full" 
                 data-transform_idle="o:1;"
                 data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;"
                 data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;"  
                 data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
                 data-mask_out="x:0;y:0;s:inherit;e:inherit;" 
                data-start="1200"
                 style="z-index: 12;">
             <a href="#order-form" class="btn-common btn-white page-scroll slider-btn">Order Now</a>
           </div>  
          </li>
				<!-- SLIDE  -->
			</ul>
		</div>
	</div>
 <!-- END REVOLUTION SLIDER -->


<!--Features Section-->
<!-- <section class="feature_wrap padding-half" id="specialities">
  <div class="container">
    <div class="row">
     <div class="col-md-12 text-center">
        <h2 class="heading ">Our &nbsp; Specialities</h2>
        <hr class="heading_space">
      </div>
    </div>
    <div class="row">
      <div class="col-md-3 col-sm-6 feature text-center">
        <i class="icon-glass"></i>
        <h3><a href="about.php">Our Mission</a></h3>
        <p>We are committed to pursue excellence for manufacturing world-class food</p>
      </div>
      <div class="col-md-3 col-sm-6 feature text-center">
        <i class="icon-coffee"></i>
        <h3><a href="about.php">Our Vision</a></h3>
        <p>Our vision is to become a global leader in Food & Beverage (F&B) sector</p>
      </div>
      <div class="col-md-3 col-sm-6 feature text-center">
        <i class="icon-glass"></i>
        <h3><a href="about.php">Our Values</a></h3>
        <p> Poverty & Hunger are curses, our aim is to generate employment </p>
      </div>
      <div class="col-md-3 col-sm-6 feature text-center">
        <i class="icon-coffee"></i>
        <h3><a href="about.php">Our Goal</a></h3>
        <p>Our goal is to become a global leader in Food & Beverage (F&B) sector</p>
      </div>
    </div>
    
  </div>
</section> -->


<!--Services plus working hours-->
<section id="services" class="padding-bottom padding-half">
  <div class="container">
    <div class="row">
      <div class="col-md-12 text-center">
         <h2 class="heading">Featured &nbsp; Food</h2>
         <hr class="heading_space">
         <div class="slider_wrap">
        <div id="service-slider" class="owl-carousel">
          <div class="item">
            <div class="item_inner">
            <div class="image">
              <img src="images/food-1.jpg" alt="Feature Product">
              <a  href="categorical-product.php"></a>
            </div>
              <h3><a href="categorical-product.php">Biscuits</a></h3>
              <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore nulla facilisis.</p>
            </div>
          </div>
          <div class="item">
            <div class="item_inner">
              <div class="image">
              <img src="images/food-2.jpg" alt="Feature Product">
              <a  href="categorical-product.php"></a>
              </div>
              <h3><a href="categorical-product.php">Culinary</a></h3>
              <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore nulla facilisis.</p>
            </div>
          </div>
          <div class="item">
            <div class="item_inner">
              <div class="image">
              <img src="images/gallery13.jpg" alt="Feature Product">
              <a  href="categorical-product.php"></a>
              </div>
              <h3><a href="categorical-product.php">Spice</a></h3>
              <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore nulla facilisis.</p>
            </div>
          </div>
          <div class="item">
            <div class="item_inner">
              <div class="image">
              <img src="images/gallery2.jpg" alt="Feature Product">
              <a  href="categorical-product.php"></a>
              </div>
              <h3><a href="categorical-product.php">Beverage</a></h3>
              <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore nulla facilisis.</p>
            </div>
          </div>
          <div class="item">
            <div class="item_inner">
              <div class="image">
              <img src="images/food-4.jpg" alt="Feature Product">
              <a  href="categorical-product.php"></a>
              </div>
              <h3><a href="categorical-product.php">Snacks</a></h3>
              <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore nulla facilisis.</p>
            </div>
          </div>
        </div>
        </div>
      </div>
      <!-- <div class="col-md-4">
        <h2 class="heading">Our &nbsp; Menu</h2>
        <hr class="heading_space">
        <ul class="menu_widget">
          <li>Biscuit<span>$499.00</span></li>
          <li>Cakes<span>$249.00</span></li>
          <li>Basic Spices<span>$150.00</span></li>
          <li>Mixed Spices<span>$199.00</span></li>
          <li>Snacks<span>$99.00</span></li>
          <li>Pickles<span>$899.00</span></li>
          <li>Rice<span>$1250.00</span></li>
          <li>Culinary<span>$399.00</span></li>
        </ul>
         <h3>Other Products Menu</h3>
         <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse <strong>molestie consequat</strong>, vel illum dolore nulla facilisis.</p>
      </div> -->
    </div>
  </div>
</section>


<!-- image with content -->
<section class="info_section paralax">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
         <div class="text-center">
           <h2 class="heading_space">About Raj-Kamal Everbest Corporation Ltd.</h2>
           <p class="heading_space detail">"RAJ-KAMAL" is currently one of the most well known brand among the millions of people in Bangladesh and abroad. Since its origin in 1995, RAJ-KAMAL Foods has grown up in stature and became one of the largest Indian spices and dry food exporter in Bangladesh. RAJ-KAMAL is the pioneer in Bangladesh to be involved procures raw material directly from the farmers and processes through state of the machinery at our factory into hygienically packed food and drinks products. The brand "RAJ-KAMAL" has established itself in every category of food and can boost a product range from Drinks, Confectionery, Snacks, and Spices and Bakery products.</p>
           <a href="company-profile.php" class="btn-common-white page-scroll">Learn More</a>
         </div>          
      </div>
    </div>
  </div>
</section>

<!-- Food Gallery -->
<section id="gallery" class="padding">
  <div class="container">
      <div class="row">
     <div class="col-md-12 text-center">
        <h2 class="heading ">Our &nbsp; Products</h2>
        <hr class="heading_space">
        <div class="work-filter">
          <ul class="text-center">
             <li><a href="javascript:;" data-filter="all" class="active filter">All Products</a></li>
             <li><a href="javascript:;" data-filter=".biscuit" class="filter">Biscuits</a></li>
             <li><a href="javascript:;" data-filter=".culinary" class="filter">Culinary</a></li>
             <li><a href="javascript:;" data-filter=".beverage" class="filter"> Beverage</a></li>
             <li><a href="javascript:;" data-filter=".pickle" class="filter"> Snacks</a></li>
             <li><a href="javascript:;" data-filter=".spice" class="filter">Other Items</a></li>
          </ul>
        </div>
      </div>
    </div>
     <div class="row">
      <div class="zerogrid">
        <div class="wrap-container">
          <div class="wrap-content clearfix home-gallery">
            <div class="col-1-4 mix work-item biscuit">
              <div class="wrap-col">
                <div class="item-container">
                  <a class="fancybox" href="images/gallery1.jpg" data-fancybox-group="gallery">
                    <div class="image">
                      <img src="images/gallery1.jpg" alt="product"/>
                      <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery1.jpg" data-fancybox-group="gallery" title="Sweet Toast"><i class=" icon-eye6"></i></a>
                    </div>
                    </div>
                  </a>
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item culinary">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery2.jpg" alt="product"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery2.jpg" data-fancybox-group="gallery" title="Mustard Oil"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item biscuit">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery3.jpg" alt="product"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery3.jpg" data-fancybox-group="gallery" title="Cake Rusk"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item culinary">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery4.jpg" alt="product"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery4.jpg" data-fancybox-group="gallery" title="Aromatic Rice"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>  
            <div class="col-1-4 mix work-item biscuit">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery5.jpg" alt="product"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery5.jpg" data-fancybox-group="gallery" title="Salty Cookies"><i class=" icon-eye6"></i></a>
                    </div> 
                  </div>
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item culinary">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery6.jpg" alt="product"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery6.jpg" data-fancybox-group="gallery" title="pulses"><i class=" icon-eye6"></i></a>
                    </div>
                  </div> 
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item biscuit">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery7.jpg" alt="product"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery7.jpg" data-fancybox-group="gallery" title="Dry Cake"><i class=" icon-eye6"></i></a>
                    </div>
                  </div> 
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item culinary">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery8.jpg" alt="product"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery8.jpg" data-fancybox-group="gallery" title="Chakki Fresh Atta"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item spice">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery9.jpg" alt="product"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery9.jpg" data-fancybox-group="gallery" title="Coriander Powder"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item pickle">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery10.png" alt="product"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery10.png" data-fancybox-group="gallery" title="Mango Pickle"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item spice">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery11.jpg" alt="product"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery11.jpg" data-fancybox-group="gallery" title="Chicken Masala"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>  
            <div class="col-1-4 mix work-item snack">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery12.jpg" alt="product"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery12.jpg" data-fancybox-group="gallery" title="Jhal Muri"><i class=" icon-eye6"></i></a>
                    </div> 
                  </div>
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item spice">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery13.jpg" alt="product"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery13.jpg" data-fancybox-group="gallery" title="Chilli Powder"><i class=" icon-eye6"></i></a>
                    </div>
                  </div> 
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item pickle">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery14.jpg" alt="product"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery14.jpg" data-fancybox-group="gallery" title="Mixed Pickle"><i class=" icon-eye6"></i></a>
                    </div>
                  </div> 
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item spice">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery15.jpg" alt="product"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery15.jpg" data-fancybox-group="gallery" title="Turmeric Powder"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item snack">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery16.jpg" alt="product"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery16.jpg" data-fancybox-group="gallery" title="Potato Crackers"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item pickle">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery17.jpg" alt="product"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery17.jpg" data-fancybox-group="gallery" title="Chalta Pickle"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>  
            <div class="col-1-4 mix work-item snack">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery18.jpg" alt="product"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery18.jpg" data-fancybox-group="gallery" title="BBQ Chanachur"><i class=" icon-eye6"></i></a>
                    </div> 
                  </div>
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item pickle">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery19.jpg" alt="product"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery19.jpg" data-fancybox-group="gallery" title="Chilli Pickle"><i class=" icon-eye6"></i></a>
                    </div>
                  </div> 
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item snack">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery20.jpg" alt="product"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery20.jpg" data-fancybox-group="gallery" title="Hot Chanachur"><i class=" icon-eye6"></i></a>
                    </div>
                  </div> 
                </div>
              </div>
            </div>
          </div>
        </div>
       </div>
      </div>
  </div>
</section>


<!-- facts counter  -->
<section id="facts">
  <div class="container">
    <div class="row number-counters"> 
      <!-- first count item -->
      <!-- <div class="col-sm-3 col-xs-12 text-center wow fadeInDown" data-wow-duration="500ms" data-wow-delay="300ms">
        <div class="counters-item row">
        <i class="icon-smile"></i> 
        <h2><strong data-to="4680">0</strong></h2>
          <p>Happy Customers</p>
        </div>
      </div> -->
      <div class="col-sm-6 col-xs-12 text-center wow fadeInDown" data-wow-duration="500ms" data-wow-delay="600ms">
        <div class="counters-item  row"> 
        <i class="icon-food"></i>
        <h2><strong data-to="10000">0</strong></h2>
          <p>Export Footprint</p>
        </div>
      </div>
      <div class="col-sm-6 col-xs-12 text-center wow fadeInDown" data-wow-duration="500ms" data-wow-delay="900ms">
        <div class="counters-item  row"> 
        <i class="icon-glass"></i>
        <h2><strong data-to="30000">0</strong></h2>
          <p>Total Products</p>
        </div>
      </div>
      <!-- <div class="col-sm-3 col-xs-12 text-center wow fadeInDown" data-wow-duration="500ms" data-wow-delay="1200ms">
        <div class="counters-item  row"> 
        <i class="icon-coffee"></i>
        <h2><strong data-to="1350">0</strong></h2>
          <p>Total Products</p>
        </div>
      </div> -->
    </div>  
  </div>
</section>

<!--Featured Receipes -->
<section id="news" class="bg_grey padding">
  <div class="container">
    <div class="row">
      <div class="col-md-12 text-center">
      <h2 class="heading">Our &nbsp; Brands</h2>
      <hr class="heading_space">
      </div>
    </div>
    <div class="row">
      <div class="col-md-12 text-center">
        <div class="cheffs_wrap_slider">
          <div id="news-slider" class="owl-carousel">
            <div class="item">
              <div class="news_content">
               <img src="images/brands/brand1.png" alt="Brand">
               <div class="comment_text">
                 <h3><a href="#.">Bakers</a></h3>
               </div>
              </div>
            </div>
            <div class="item">
              <div class="news_content">
               <img src="images/brands/brand2.png" alt="Brand">
               <div class="comment_text">
                 <h3><a href="#.">Ranna</a></h3>
               </div>
              </div>
            </div>
            <div class="item">
              <div class="news_content">
               <img src="images/brands/brand3.png" alt="Brand">
               <div class="comment_text">
                 <h3><a href="#.">Mezban</a></h3>
               </div>
              </div>
            </div>
            <div class="item">
              <div class="news_content">
               <img src="images/brands/brand4.png" alt="Brand">
               <div class="comment_text">
                 <h3><a href="#.">Toffee Bites</a></h3>
               </div>
              </div>
            </div>
            <div class="item">
              <div class="news_content">
               <img src="images/brands/brand5.png" alt="Brand">
               <div class="comment_text">
                 <h3><a href="#.">Shahi Laccha</a></h3>
               </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<!-- Order Online --> 
<section id="order-form" class="order_section">
  <div class="container order_form padding">
    <div class="row">
      <div class="col-md-12 appointment_form">
        <h2 class="heading">Online Order</h2>
        <hr class="heading_space">
      <div class="row">  
       <div class="col-md-8">
       <form onSubmit="return false" id="order_form" class="callus">
            <div class="row">
            <div class="form-group col-md-12">
            <div id="result" class="text-center"></div></div></div>
             <div class="row">
             <div class="form-group col-md-12">
            <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat.</p>
            </div></div>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="Name"  name="name" id="name"  required>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                   <input type="email" class="form-control" placeholder="Email address" name="email" id="email" required>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="Phone No" name="phone" id="phone" required>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <select class="form-control" id="deal" name="deal">
                       <option value="Not Selected"> Select Deal </option>
                       <option> Deal One ($200) </option>
                       <option> Deal Two ($500) </option>
                       <option> Deal Three ($900) </option>
                       <option> Deal Four ($1300) </option>
                    </select>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <textarea placeholder="Order Details"  id="message" name="message" required></textarea>
                  </div>

                  <div class="form-group">
                     <div class="btn-submit btn-common-white">
                    <input type="submit" value="Place &nbsp; Order" id="btn_order_submit" />
                    </div>
                  </div>
                </div>
              </div>
            </form>
           </div> 
           </div>
      </div>
      <div class="col-md-3">
      </div>
    </div>
    <div class="col-md-3"></div>
  </div>
</section>


<!-- testinomial -->
<section id="testinomial" class="padding">
  <div class="container">
  <div class="row">
      <div class="col-md-12 text-center">
      <h2 class="heading">Our &nbsp; happy &nbsp; Customers</h2>
      <hr class="heading_space">
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
      <div id="testinomial-slider" class="owl-carousel text-center">
        <div class="item">
          <h3>Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram.</h3>
          <p>Chris Martin</p>
        </div>
        <div class="item">
          <h3>Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. quam nunc putamus parum claram, Mirum est notare quam littera gothica.</h3>
          <p>Alex Hales</p>
        </div>
        <div class="item">
          <h3>Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse.</h3>
          <p>Shane Robertson</p>
        </div>
       </div>
      </div>
    </div>
  </div>
</section>


<?php include('includes/footer.php')?>