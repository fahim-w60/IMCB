<?php include('includes/header.php')?>

<!--Page header & Title-->
<section id="page_header">
<div class="page_title">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
         <h2 class="title">Export</h2>
         <p>Raj-Kamal Everbest Corporation Ltd.</p>
      </div>
    </div>
  </div>
</div>  
</section>


<section class="export padding-half" id="specialities">
  <div class="container">
    <div class="row">
     <div class="col-md-12 text-center">
        <h2 class="heading ">Export Footprint</h2>
        <hr class="heading_space">
      </div>
      <div class="coverage-map"> 
        <img src="images/export.jpg" alt="" class="img-responsive">
      </div>
    </div>
  </div>
</section>


<section id="gallery" class="export-product">
  <div class="container">
    <div class="row">
      <div class="col-md-12 text-center">
        <h2 class="heading">Export Products</h2>
        <hr class="heading_space">

        <div class="work-filter">
          <ul class="text-center">
             <li><a href="javascript:;" data-filter="all" class="active filter">All Food</a></li>
             <li><a href="javascript:;" data-filter=".biscuit" class="filter">Biscuits</a></li>
             <li><a href="javascript:;" data-filter=".culinary" class="filter">Culinary</a></li>
             <li><a href="javascript:;" data-filter=".snack" class="filter"> Snacks</a></li>
             <li><a href="javascript:;" data-filter=".snack" class="filter"> Beverage</a></li>
             <li><a href="javascript:;" data-filter=".pickle" class="filter">Other Items</a></li>
          </ul>
        </div>
      </div>
    </div>
     <div class="row">
      <div class="zerogrid">
        <div class="wrap-container">
          <div class="wrap-content clearfix home-gallery">
            <div class="col-1-4 mix work-item biscuit">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery1.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery1.jpg" data-fancybox-group="gallery" title="Product Title"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item culinary">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery2.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery2.jpg" data-fancybox-group="gallery" title="Product Title"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item biscuit">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery3.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery3.jpg" data-fancybox-group="gallery" title="Product Title"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item culinary">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery4.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery4.jpg" data-fancybox-group="gallery" title="Product Title"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>  
            <div class="col-1-4 mix work-item biscuit">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery5.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery5.jpg" data-fancybox-group="gallery" title="Product Title"><i class=" icon-eye6"></i></a>
                    </div> 
                  </div>
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item culinary">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery6.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery6.jpg" data-fancybox-group="gallery" title="Product Title"><i class=" icon-eye6"></i></a>
                    </div>
                  </div> 
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item biscuit">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery7.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery7.jpg" data-fancybox-group="gallery" title="Product Title"><i class=" icon-eye6"></i></a>
                    </div>
                  </div> 
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item culinary">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery8.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery8.jpg" data-fancybox-group="gallery" title="Product Title"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item spice">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery9.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery9.jpg" data-fancybox-group="gallery" title="Product Title"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item pickle">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery10.png" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery10.png" data-fancybox-group="gallery" title="Product Title"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item spice">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery11.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery11.jpg" data-fancybox-group="gallery" title="Product Title"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>  
            <div class="col-1-4 mix work-item snack">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery12.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery12.jpg" data-fancybox-group="gallery" title="Product Title"><i class=" icon-eye6"></i></a>
                    </div> 
                  </div>
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item spice">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery13.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery13.jpg" data-fancybox-group="gallery" title="Product Title"><i class=" icon-eye6"></i></a>
                    </div>
                  </div> 
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item pickle">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery14.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery14.jpg" data-fancybox-group="gallery" title="Product Title"><i class=" icon-eye6"></i></a>
                    </div>
                  </div> 
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item spice">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery15.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery15.jpg" data-fancybox-group="gallery" title="Product Title"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item snack">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery16.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery16.jpg" data-fancybox-group="gallery" title="Product Title"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item pickle">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery17.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery17.jpg" data-fancybox-group="gallery" title="Product Title"><i class=" icon-eye6"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>  
            <div class="col-1-4 mix work-item snack">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery18.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery18.jpg" data-fancybox-group="gallery" title="Product Title"><i class=" icon-eye6"></i></a>
                    </div> 
                  </div>
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item pickle">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery19.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery19.jpg" data-fancybox-group="gallery" title="Product Title"><i class=" icon-eye6"></i></a>
                    </div>
                  </div> 
                </div>
              </div>
            </div>
            <div class="col-1-4 mix work-item snack">
              <div class="wrap-col">
                <div class="item-container">
                  <div class="image">
                    <img src="images/gallery20.jpg" alt="cook"/>
                    <div class="overlay">
                        <a class="fancybox overlay-inner" href="images/gallery20.jpg" data-fancybox-group="gallery" title="Product Title"><i class=" icon-eye6"></i></a>
                    </div>
                  </div> 
                </div>
              </div>
            </div>
          </div>
        </div>
       </div>
      </div>
  </div>
</section>


<?php include('includes/footer.php')?>