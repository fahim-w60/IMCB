<?php include('includes/header.php')?>

<!--Page header & Title-->
<section id="page_header">
<div class="page_title">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
         <h2 class="title">Our Factory</h2>
         <p>Raj-Kamal Everbest Corporation Ltd.</p>
      </div>
    </div>
  </div>
</div>  
</section>

<div class="map-area padding-top mb40"> 
  <div class="container">
    <div class="row">
      <div class="col-md-12 text-center "> 
          <h2 class="heading">Factory Location</h2>
          <hr class="heading_space">
      </div>
    </div>
    <div class="row">
      <div class="col-md-4">
        <div class="map-address"> 
          <ul class="welcome_list">
            <li><strong>Phone:</strong> 88-02-7125613</li>
            <li><strong>Email:</strong> <a href="mailto:rajkamal_bd@hotmail.com">rajkamal_bd@hotmail.com</a></li>
            <li><strong>Address:</strong> Rayerbagh, Chittagong Road, Dhaka, Bangladesh.</li>
          </ul> 
        </div>
      </div>

      <div class="col-md-8"> 
        <div class="map"> 
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7307.023085844433!2d90.45376537293014!3d23.693419862985635!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755b767a022cd4b%3A0xaf33907e219d127!2sRayerbag%2C%20Dhaka!5e0!3m2!1sen!2sbd!4v1612435239435!5m2!1sen!2sbd" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include('includes/footer.php')?>