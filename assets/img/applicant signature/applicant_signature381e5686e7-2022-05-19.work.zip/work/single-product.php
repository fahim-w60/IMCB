<?php include('includes/header.php')?>

<!--Page header & Title-->
<section id="page_header">
<div class="page_title">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
         <h2 class="title">Single Product</h2>
         <p>Raj-Kamal Everbest Corporation Ltd.</p>
      </div>
    </div>
  </div>
</div>  
</section>

<div class="map-area padding-top mb40"> 
  <div class="container">
    <div class="row">
      <div class="col-md-12 text-center "> 
          <h2 class="heading">Product Detail</h2>
          <hr class="heading_space">
      </div>
    </div>
    <div class="row">
      <div class="col-md-4">
        <div class="map-address"> 
          <ul class="welcome_list">
            <li><strong>Name:</strong> Chili Bottle 250 GM</li>
            <li><strong>Description:</strong> Raj-Kamal Chili Powder guarantees the proper composition of curcumin and the chili selected for processing are finest of their kind. As a result it gives the dishes an attractive red color.</li>
            <li><strong>Available in:</strong> 15 gm, 50 gm, 100 gm, 200 gm, 400 gm, 500 gm, 1000 gm</li>
          </ul> 
        </div>
      </div>

      <div class="col-md-8"> 
        <div class="map"> 
          <img src="images/gallery13.jpg" alt="cook"/>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include('includes/footer.php')?>