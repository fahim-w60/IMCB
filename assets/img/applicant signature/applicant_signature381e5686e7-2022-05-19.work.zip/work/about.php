<?php include('includes/header.php')?>

<!--Page header & Title-->
<section id="page_header">
<div class="page_title">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
         <h2 class="title">About Us</h2>
         <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit</p>
      </div>
    </div>
  </div>
</div>  
</section>

<!--Welcome-->
<section id="welcome" class="padding profile">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
         <h2 class="heading">About Founder Chairman</h2>
         <hr class="heading_space">
      </div>
      <div class="col-md-7 col-sm-6">
        <ul class="welcome_list">
          <li>Name: Michael Jordan</li>
          <li>Position: Founder Chairman</li>
          <li>Office: Purana Paltan, Dhaka-1000</li>
          <li>Phone: +880-1911-222333</li>
          <li>Email: founder@mail.com</li>
        </ul> 

        <blockquote class="bg_grey half-space">Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel 
          illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue 
          duis dolore te feugait nulla facilisi.
        </blockquote>

        <div class="signature align-items-center"> 
          <div class="col-md-6"> 
            <div class="signature-img"> 
              <img src="images/sign.png" alt="SIGN" class="img-fluid">
            </div>
          </div>
          <div class="col-md-6">
            <div class="sign-author"> 
              <h3>Michael Jordan</h3>
              <p>Founder Chairman</p>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-5 col-sm-6">
       <img class="img-responsive" src="images/welcome.jpg" alt="About">
      </div>
    </div>
  </div>
</section> 

<!--Welcome-->
<section id="welcome" class="profile">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
         <h2 class="heading">Chairman's Message</h2>
         <hr class="heading_space">
      </div>

      <div class="col-md-6 text-right">
         <h2 class="heading">Managing Director's Message</h2>
         <hr class="heading_space">
      </div>
    </div>

    <div class="row">
      <div class="col-md-6 col-sm-6">

        <blockquote class="bg_grey half-space">Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel 
          illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue 
          duis dolore te feugait nulla facilisi.
        </blockquote>
      </div>

      <div class="col-md-6 col-sm-6 text-right">

        <blockquote class="bg_grey half-space">Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel 
          illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue 
          duis dolore te feugait nulla facilisi.
        </blockquote>
      </div>

    </div>
  </div>
</section>  

  <!--Blue Section-->
  <section class="company-profile padding-half">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
           <h2 class="heading">Company &nbsp; Overview</h2>
           <hr class="heading_space">
        </div>
      </div>

      <div class="row">
        <div class="col-md-6"> 
          <div class="company-attr">

            <div class="row number-counters">
              <div class="col-sm-6 col-xs-12 text-center wow fadeInDown" data-wow-duration="500ms" data-wow-delay="300ms">
                <div class="counters-item">
                  <i class="icon-smile"></i> 
                  <h2><strong data-to="865">0</strong></h2>
                  <h3>Total Employees</h3>
                  <p> you need a doctor for to consectetuer Lorem ipsum dolor.</p>
                </div>
              </div>
              <div class="col-sm-6 col-xs-12 text-center wow fadeInDown" data-wow-duration="500ms" data-wow-delay="600ms">
                <div class="counters-item"> 
                  <i class="icon-food"></i>
                  <h2><strong data-to="4680">0</strong></h2>
                  <h3>Happy Customers</h3>
                  <p> you need a doctor for to consectetuer Lorem ipsum dolor.</p>
                </div>
              </div>
              <div class="col-sm-6 col-xs-12 text-center wow fadeInDown" data-wow-duration="500ms" data-wow-delay="900ms">
                <div class="counters-item"> 
                  <i class="icon-glass"></i>
                  <h2><strong data-to="510">0</strong></h2>
                  <h3>Per Day Served</h3>
                  <p> you need a doctor for to consectetuer Lorem ipsum dolor.</p>
                </div>
              </div>
              <div class="col-sm-6 col-xs-12 text-center wow fadeInDown" data-wow-duration="500ms" data-wow-delay="900ms">
                <div class="counters-item"> 
                  <i class="icon-glass"></i>
                  <h2><strong data-to="450">0</strong></h2>
                  <h3>Total Beverages</h3>
                  <p> you need a doctor for to consectetuer Lorem ipsum dolor.</p>
                </div>
              </div>
            </div> 

            <!-- <div class="col-md-6 col-sm-6 black_content">
              <i class="icon-glass"></i>
              <h3>Employees</h3>
              <p> you need a doctor for to consectetuer Lorem ipsum dolor, consectetur adipiscing onsectetur Graphic Power Ut eros.</p>
            </div>
            <div class="col-md-6 col-sm-6 black_content">
              <i class="icon-coffee"></i>
              <h3><a href="services.php">Customers</a></h3>
              <p> you need a doctor for to consectetuer Lorem ipsum dolor, consectetur adipiscing onsectetur Graphic Power Ut eros.</p>
            </div>
            <div class="col-md-6 col-sm-6 black_content">
              <i class="icon-coffee2"></i>
              <h3><a href="services.php">Workers</a></h3>
              <p> you need a doctor for to consectetuer Lorem ipsum dolor, consectetur adipiscing onsectetur Graphic Power Ut eros.</p>
            </div>
            <div class="col-md-6 col-sm-6 black_content">
              <i class="icon-glass2"></i>
              <h3><a href="services.php">Machines</a></h3>
              <p> you need a doctor for to consectetuer Lorem ipsum dolor, consectetur adipiscing onsectetur Graphic Power Ut eros.</p>
            </div> -->
          </div>
        </div>

        <div class="col-md-6"> 
          <div class="company-text"> 
            <img class="img-responsive" src="images/about.jpg" alt="About">
          </div>
        </div>
      </div>
    </div>
  </section>

<!-- <section id="overview" class="padding-top">
  <div class="container">
    <div class="row">
      <div class="col-sm-12">
         <h2 class="heading">Restaurant &nbsp; Overview</h2>
         <hr class="heading_space">
         <p>Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. quam nunc putamus parum claram, Mirum est notare quam littera gothica Mirum est notare quam littera gothica Mirum est notare quam littera gothicaMirum est notare quam littera gothica. Mirum est notare quam littera gothica Mirum est notare quam littera gothica Mirum est notare quam littera gothicaMirum est notare quam littera gothica.</p>
      </div>
    </div>
  </div>
</section> -->



<?php include('includes/footer.php')?>